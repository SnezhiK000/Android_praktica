package com.example.practika_0103


class Note_adapter {
}