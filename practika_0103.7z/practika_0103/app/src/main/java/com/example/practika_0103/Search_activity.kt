package com.example.practika_0103

class Search_activity {
}