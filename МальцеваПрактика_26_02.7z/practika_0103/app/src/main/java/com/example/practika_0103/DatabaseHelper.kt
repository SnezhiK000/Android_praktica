package com.example.practika_0103
import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Date
import kotlin.apply


const val TABLE_NAME = "Notes"
const val DB_NAME = "OurBase.db"

const val ID_NAME = "id"
const val TITLE_NAME = "title"
const val CONTENT_NAME = "content"
const val DATE_NAME = "date"

class DatabaseHelper {

    class OurBase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, 1) {

        override fun onCreate(db: SQLiteDatabase) {
            val createTable =
                "CREATE TABLE $TABLE_NAME ($ID_NAME, $TITLE_NAME, $CONTENT_NAME, $DATE_NAME)"
            db.execSQL(createTable)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
            onCreate(db)
        }


        // Добавление
        fun addNotes(title: String, content: String, date: Date): Long {

            val db = this.writableDatabase

            val values = ContentValues().apply {
                put(TITLE_NAME, title)
                put(CONTENT_NAME, content)
                put(DATE_NAME, date)
            }

            // Возвращение ID новой строки
            return db.insert(TABLE_NAME, null, values)
        }


        // Чтение всех записей
        fun getAllNotes(): List<Notes> {
            val notesList = mutableListOf<Notes>()
            val db = this.readableDatabase
            val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)

            if (cursor.moveToFirst()) {
                do {
                    val note = Notes(

                        id = cursor.getInt(cursor.getColumnIndexOrThrow(ID_NAME)),
                        title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_NAME)),
                        content = cursor.getString(cursor.getColumnIndexOrThrow(CONTENT_NAME)),
                        date = cursor.getString(cursor.getColumnIndexOrThrow(DATE_NAME)),
                    )

                    // Добавление в список
                    notesList.add(note)
                } while (cursor.moveToNext())
            }
            cursor.close()
            return notesList
        }

        // Обновление
        fun updateNotes(id: Int, newTitle: String): Int {
            val db = this.writableDatabase
            val values = ContentValues().apply {
                put(TITLE_NAME, newTitle)
            }

            // Возвращение количества измененных строк
            return db.update(TABLE_NAME, values, "$ID_NAME = ?", arrayOf(id.toString()))
        }

        // Удаление
        fun deleteNotes(id: Int): Int {
            val db = this.writableDatabase

            // Возвращение количества удаленных строк
            return db.delete(TABLE_NAME, "$ID_NAME = ?", arrayOf(id.toString()))

        }
    }
}