package com.example.practika_0103
import java.util.Date


//Таблица заметок
data class Notes (
    var id: Int = 0,
    var title: String,
    var content: String,
    var date: Date,
)