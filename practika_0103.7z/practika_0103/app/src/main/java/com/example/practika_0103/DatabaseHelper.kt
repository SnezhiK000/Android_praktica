package com.example.practika_0103
import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlin.apply


const val TABLE_NAME = "Notes"
const val DB_NAME = "OurBase.db"

const val ID_NAME = "id"
const val TITLE_NAME = "title"
const val CONTENT_NAME = "content"
const val DATE_NAME = "date"

class DatabaseHelper {

    class OurBase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, 1) {

        override fun onCreate(db: SQLiteDatabase) {
            val createTable =
                "CREATE TABLE $TABLE_NAME ($ID_NAME, $NM_NAME, $PRICE_NAME, $CAT_NAME, $DES_NAME)"
            db.execSQL(createTable)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
            onCreate(db)
        }


        // Добавление
        fun addProduct(name: String, price: Double, category: String, description: String): Long {

            val db = this.writableDatabase

            val values = ContentValues().apply {
                put(NM_NAME, name)
                put(PRICE_NAME, price)
                put(CAT_NAME, category)
                put(DES_NAME, description)
            }

            // Возвращение ID новой строки
            return db.insert(TABLE_NAME, null, values)
        }


        // Чтение всех записей
        fun getAllProducts(): List<Products> {
            val productsList = mutableListOf<Products>()
            val db = this.readableDatabase
            val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)

            if (cursor.moveToFirst()) {
                do {
                    val product = Products(

                        id = cursor.getInt(cursor.getColumnIndexOrThrow(ID_NAME)),
                        name = cursor.getString(cursor.getColumnIndexOrThrow(NM_NAME)),
                        price = cursor.getDouble(cursor.getColumnIndexOrThrow(PRICE_NAME)),
                        category = cursor.getString(cursor.getColumnIndexOrThrow(CAT_NAME)),
                        description = cursor.getString(cursor.getColumnIndexOrThrow(DES_NAME)),
                    )

                    // Добавление в список
                    productsList.add(product)
                } while (cursor.moveToNext())
            }
            cursor.close()
            return productsList
        }

        // Обновление
        fun updateProduct(id: Int, newName: String): Int {
            val db = this.writableDatabase
            val values = ContentValues().apply {
                put(NM_NAME, newName)
            }

            // Возвращение количества измененных строк
            return db.update(TABLE_NAME, values, "$ID_NAME = ?", arrayOf(id.toString()))
        }

        // Удаление
        fun deleteProduct(id: Int): Int {
            val db = this.writableDatabase

            // Возвращение количества удаленных строк
            return db.delete(TABLE_NAME, "$ID_NAME = ?", arrayOf(id.toString()))

        }
    }
}